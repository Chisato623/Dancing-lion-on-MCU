/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "board.h"
#include <stdio.h>
#include "lcd_init.h"
#include "lcd.h"
#include "pic.h"

int main(void)
{
        
    board_init();
    
    
    u8 i,j;
    float t=0;

    LCD_Init();//LCD��ʼ��
    LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
   
    while(1)
    {
        LCD_ShowString(0,40,(uint8_t *)"LCD_W:",RED,WHITE,16,0);
        LCD_ShowIntNum(48,40,LCD_W,3,RED,WHITE,16);
        LCD_ShowString(80,40,(uint8_t *)"LCD_H:",RED,WHITE,16,0);
        LCD_ShowIntNum(128,40,LCD_H,3,RED,WHITE,16);
        LCD_ShowString(80,40,(uint8_t *)"LCD_H:",RED,WHITE,16,0);
        LCD_ShowString(0,70,(uint8_t *)"Increaseing Nun:",RED,WHITE,16,0);
        LCD_ShowFloatNum1(128,70,t,4,RED,WHITE,16);
        for(j=0;j<3;j++)
        {
            for(i=0;i<6;i++)
            {
                    LCD_ShowPicture(40*i,120+j*40,40,40,gImage_1);
            }
        }
        delay_ms(1000);
        LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
        Display_Asc_String(0,15,7, (uint8_t *)"ASCII_5x7",RED,WHITE);      //ASC 5X7����
        Display_Asc_String(0,25,8, (uint8_t *)"ASCII_7x8",RED,WHITE);      //ASC 7X8����
        Display_Asc_String(0,35,12, (uint8_t *)"ASCII_6x12",RED,WHITE);          //ASC 6X12����
        Display_Asc_String(0,50,16, (uint8_t *)"ASCII_8x16",RED,WHITE);          //ASC 8X16����
        Display_Asc_String(0,70,24, (uint8_t *)"ASCII_12x24",RED,WHITE);   //ASC 12X24����
        Display_Asc_String(0,100,32, (uint8_t *)"ASCII_16x32",RED,WHITE);        //ASC 16X32����  
        Display_GB2312_String(0,145,12, "��Ļ����������",RED,WHITE); //12x12����
        Display_GB2312_String(0,160,16, "��Ļ����������",RED,WHITE); //15x16����
        Display_GB2312_String(0,179,24, "��Ļ����������",RED,WHITE); //24x24����
        Display_GB2312_String(0,204,32, "��Ļ��������",RED,WHITE);   //32x32����
        delay_ms(1000);
        LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
        
        Display_TimesNewRoman_String(0,15,12, (uint8_t *)"ASCII_8x12",RED,WHITE);   //ASC 8x12����(TimesNewRoman����)
        Display_TimesNewRoman_String(0,30,16, (uint8_t *)"ASCII_12x16",RED,WHITE);  //ASC 12x16����(TimesNewRoman����)
        Display_TimesNewRoman_String(0,50,24, (uint8_t *)"ASCII_16x24",RED,WHITE);        //ASC 16x24����(TimesNewRoman����)
        Display_TimesNewRoman_String(0,80,32, (uint8_t *)"ASCII_24x",RED,WHITE);          //ASC 24x32����(TimesNewRoman����)
        Display_Arial_String(0,120,12, (uint8_t *)"ASCII_8x12",RED,WHITE);    //ASC 8x12����(Arial����)
        Display_Arial_String(0,140,16, (uint8_t *)"ASCII_12x16",RED,WHITE);   //ASC 12x16����(Arial����)
        Display_Arial_String(0,160,24, (uint8_t *)"ASCII_16x24",RED,WHITE);         //ASC 16x24����(Arial����)
        Display_Arial_String(0,190,32, (uint8_t *)"ASCII_24x",RED,WHITE);           //ASC 24x32����(Arial����)
        delay_ms(1000);
                
//                t+=0.11;
                
        LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
    }
        
}















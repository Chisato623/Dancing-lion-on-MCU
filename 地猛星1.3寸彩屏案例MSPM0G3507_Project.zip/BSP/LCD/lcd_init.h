#ifndef __LCD_INIT_H
#define __LCD_INIT_H

#include "board.h"

#define USE_HORIZONTAL 0  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����


#define LCD_W 240
#define LCD_H 240

#ifndef u8
#define u8 uint8_t
#endif

#ifndef u16
#define u16 uint16_t
#endif

#ifndef u32
#define u32 uint32_t
#endif

//-----------------LCD�˿ڶ���---------------- 

#define LCD_SCLK_Clr() DL_GPIO_clearPins(LCD_PORT,LCD_SCL_PIN)//SCL=SCLK
#define LCD_SCLK_Set() DL_GPIO_setPins(LCD_PORT,LCD_SCL_PIN)

#define LCD_MOSI_Clr() DL_GPIO_clearPins(LCD_PORT,LCD_SDA_PIN)//SDA=MOSI
#define LCD_MOSI_Set() DL_GPIO_setPins(LCD_PORT,LCD_SDA_PIN)

#define LCD_RES_Clr()  DL_GPIO_clearPins(LCD_PORT,LCD_RES_PIN)//RES
#define LCD_RES_Set()  DL_GPIO_setPins(LCD_PORT,LCD_RES_PIN)

#define LCD_DC_Clr()   DL_GPIO_clearPins(LCD_PORT,LCD_DC_PIN)//DC
#define LCD_DC_Set()   DL_GPIO_setPins(LCD_PORT,LCD_DC_PIN)
                      
#define LCD_CS_Clr()   DL_GPIO_clearPins(LCD_PORT,LCD_CS1_PIN)//CS1
#define LCD_CS_Set()   DL_GPIO_setPins(LCD_PORT,LCD_CS1_PIN)

#define LCD_BLK_Clr()  DL_GPIO_clearPins(LCD_PORT,LCD_BLK_PIN)//BLK
#define LCD_BLK_Set()  DL_GPIO_setPins(LCD_PORT,LCD_BLK_PIN)

#define ZK_MISO        DL_GPIO_readPins(LCD_PORT,LCD_FSO_PIN)//MISO  ��ȡ�ֿ���������

#define ZK_CS_Clr()    DL_GPIO_clearPins(LCD_PORT,LCD_CS2_PIN)//CS2 �ֿ�Ƭѡ
#define ZK_CS_Set()    DL_GPIO_setPins(LCD_PORT,LCD_CS2_PIN)                	




void LCD_GPIO_Init(void);//��ʼ��GPIO
void LCD_Writ_Bus(u8 dat);//ģ��SPIʱ��
void LCD_WR_DATA8(u8 dat);//д��һ���ֽ�
void LCD_WR_DATA(u16 dat);//д�������ֽ�
void LCD_WR_REG(u8 dat);//д��һ��ָ��
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);//�������꺯��
void LCD_Init(void);//LCD��ʼ��
#endif




